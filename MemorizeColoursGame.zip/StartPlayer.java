import gui.MemoryGameWindow;

public class StartPlayer {
	
	public static void main(String[] args) {
		new MemoryGameWindow();
	}

}
